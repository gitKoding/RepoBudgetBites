import { ArrowLeft, Clock, Users, ChefHat } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Recipe {
  id: number;
  name: string;
  time: string;
  servings: string;
  image: string;
}

interface RecipeDetailProps {
  recipe: Recipe;
  onBack: () => void;
}

export function RecipeDetail({ recipe, onBack }: RecipeDetailProps) {
  const ingredients = [
    '2 cups mixed vegetables (carrots, bell peppers, zucchini)',
    '1 cup quinoa',
    '3 tablespoons olive oil',
    '2 cloves garlic, minced',
    '1 teaspoon paprika',
    'Salt and pepper to taste',
    'Fresh herbs for garnish',
  ];

  const instructions = [
    'Cook quinoa according to package directions and set aside.',
    'Heat olive oil in a large pan over medium heat.',
    'Add garlic and cook for 1 minute until fragrant.',
    'Add mixed vegetables and sauté for 8-10 minutes until tender.',
    'Season with paprika, salt, and pepper.',
    'Serve vegetables over quinoa and garnish with fresh herbs.',
  ];

  return (
    <div>
      <Button
        onClick={onBack}
        variant="ghost"
        className="mb-6"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        <span>Back to Recipes</span>
      </Button>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="aspect-square bg-gray-200 rounded-3xl overflow-hidden">
          <ImageWithFallback
            src={recipe.image}
            alt={recipe.name}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="mb-4">{recipe.name}</h2>
            <div className="flex items-center gap-6 text-gray-600">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                <span>{recipe.time}</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                <span>{recipe.servings}</span>
              </div>
            </div>
          </div>

          <div className="bg-green-50 p-6 rounded-2xl">
            <div className="flex items-center gap-2 mb-3">
              <ChefHat className="h-5 w-5 text-green-600" />
              <span>Budget-Friendly</span>
            </div>
            <p className="text-gray-700">
              This recipe uses affordable ingredients you can find on sale at your local grocery stores. Estimated cost: $8-12 total.
            </p>
          </div>

          <div>
            <p className="mb-3">Ingredients</p>
            <ul className="space-y-2">
              {ingredients.map((ingredient, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-green-600 mt-1.5">•</span>
                  <span className="text-gray-700">{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-8 p-6 bg-gray-50 rounded-2xl">
        <p className="mb-4">Instructions</p>
        <ol className="space-y-4">
          {instructions.map((instruction, index) => (
            <li key={index} className="flex gap-4">
              <span className="flex items-center justify-center h-8 w-8 rounded-full bg-green-600 text-white shrink-0">
                {index + 1}
              </span>
              <span className="text-gray-700 pt-1">{instruction}</span>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
