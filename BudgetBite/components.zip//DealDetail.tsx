import { ArrowLeft, MapPin, DollarSign, Clock, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Deal {
  id: number;
  name: string;
  price: string;
  originalPrice: string;
  discount: string;
  store: string;
  location: string;
  distance: string;
  image: string;
  website: string;
}

interface DealDetailProps {
  deal: Deal;
  onBack: () => void;
}

export function DealDetail({ deal, onBack }: DealDetailProps) {
  return (
    <div>
      <Button
        onClick={onBack}
        variant="ghost"
        className="mb-6"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        <span>Back to Deals</span>
      </Button>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="aspect-square bg-gray-200 rounded-3xl overflow-hidden">
          <ImageWithFallback
            src={deal.image}
            alt={deal.name}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="mb-4">{deal.name}</h2>
            <p className="text-gray-600 mb-2">{deal.store}</p>
            <div className="flex items-center gap-2 text-gray-500">
              <MapPin className="h-4 w-4" />
              <span>{deal.distance} • {deal.location}</span>
            </div>
          </div>

          <div className="bg-green-50 p-6 rounded-2xl space-y-4">
            <div className="flex items-baseline gap-4">
              <span className="text-green-600">{deal.price}</span>
              <span className="text-gray-400 line-through">{deal.originalPrice}</span>
            </div>
            <div className="inline-block bg-green-600 text-white px-4 py-2 rounded-full">
              Save {deal.discount}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl">
              <Clock className="h-5 w-5 text-gray-600 mt-0.5" />
              <div>
                <p className="mb-1">Limited Time Offer</p>
                <p className="text-sm text-gray-600">This deal expires soon. Visit the store to redeem.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl">
              <DollarSign className="h-5 w-5 text-gray-600 mt-0.5" />
              <div>
                <p className="mb-1">Best Price Guarantee</p>
                <p className="text-sm text-gray-600">We've compared prices across all major stores in your area.</p>
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-4">
            <Button 
              className="bg-green-600 hover:bg-green-700 text-white rounded-full px-6 w-full"
              onClick={() => window.open(`https://maps.google.com/?q=${encodeURIComponent(deal.location + ', ' + deal.store)}`, '_blank')}
            >
              <MapPin className="mr-2 h-4 w-4" />
              <span>Get Directions</span>
            </Button>
            <Button 
              variant="outline"
              className="rounded-full px-6 w-full border-gray-300"
              onClick={() => window.open(`https://${deal.website}`, '_blank')}
            >
              <ExternalLink className="mr-2 h-4 w-4" />
              <span>Visit Store Website</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
