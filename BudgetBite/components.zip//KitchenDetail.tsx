import { ArrowLeft, Clock, Star, MapPin, Phone, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Kitchen {
  id: number;
  name: string;
  cuisine: string;
  rating: number;
  deliveryTime: string;
  image: string;
}

interface KitchenDetailProps {
  kitchen: Kitchen;
  onBack: () => void;
}

export function KitchenDetail({ kitchen, onBack }: KitchenDetailProps) {
  const menuItems = [
    { name: 'Organic Garden Salad', price: '$12.99' },
    { name: 'Grilled Veggie Bowl', price: '$14.99' },
    { name: 'Fresh Fruit Smoothie', price: '$8.99' },
    { name: 'Quinoa Power Bowl', price: '$13.99' },
    { name: 'Green Detox Juice', price: '$7.99' },
  ];

  return (
    <div>
      <Button
        onClick={onBack}
        variant="ghost"
        className="mb-6"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        <span>Back to Local Kitchens</span>
      </Button>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="aspect-square bg-gray-200 rounded-3xl overflow-hidden">
          <ImageWithFallback
            src={kitchen.image}
            alt={kitchen.name}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="mb-2">{kitchen.name}</h2>
            <p className="text-gray-600 mb-4">{kitchen.cuisine}</p>
            
            <div className="flex items-center gap-6 text-gray-600">
              <div className="flex items-center gap-2">
                <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                <span>{kitchen.rating} (250+ reviews)</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                <span>{kitchen.deliveryTime}</span>
              </div>
            </div>
          </div>

          <div className="bg-green-50 p-6 rounded-2xl space-y-3">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-green-600 mt-0.5" />
              <div>
                <p className="mb-1">Location</p>
                <p className="text-sm text-gray-600">123 Main Street, Downtown</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Phone className="h-5 w-5 text-green-600 mt-0.5" />
              <div>
                <p className="mb-1">Phone</p>
                <p className="text-sm text-gray-600">(555) 123-4567</p>
              </div>
            </div>
          </div>

          <div>
            <p className="mb-4">Popular Menu Items</p>
            <div className="space-y-3">
              {menuItems.map((item, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                  <span className="text-gray-700">{item.name}</span>
                  <span className="text-green-600">{item.price}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-3 pt-4">
            <Button 
              className="bg-green-600 hover:bg-green-700 text-white rounded-full px-6 w-full"
              onClick={() => window.open(`https://maps.google.com/?q=${encodeURIComponent(kitchen.name)}`, '_blank')}
            >
              <MapPin className="mr-2 h-4 w-4" />
              <span>Order for Delivery</span>
            </Button>
            <Button 
              variant="outline"
              className="rounded-full px-6 w-full border-gray-300"
              onClick={() => window.open(`tel:5551234567`, '_blank')}
            >
              <Phone className="mr-2 h-4 w-4" />
              <span>Call Restaurant</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="mt-8 p-6 bg-gray-50 rounded-2xl">
        <p className="mb-3">About {kitchen.name}</p>
        <p className="text-gray-700 leading-relaxed">
          We're committed to serving fresh, locally-sourced ingredients in every dish. Our menu features seasonal specialties that support local farmers and sustainable practices. Whether you're looking for a quick lunch or a healthy dinner option, we have something for everyone.
        </p>
      </div>
    </div>
  );
}
